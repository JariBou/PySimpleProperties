# PyProperties

An adaptation of java properties loader for python
